#ifndef EXT_SPI_H
#define EXT_SPI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include "spi.h"

/**
 * @file    ext_spi.h
 * @brief   SPI extension footprint (SPI2, SCK PD3 / MOSI PC1 / MISO PB14).
 *
 * ============================================================================
 *  FOOTPRINT FOR FUTURE SPI FEATURED PROJECTS
 * ============================================================================
 *  This module is the single place where future SPI-based features plug in.
 *  SPI2 is a 37.5 MBit/s full-duplex master (CubeMX, spi.c).  The board also
 *  routes three GPIOs for a 4-wire LCD panel:
 *      PA0 -> LCD_CS   (chip select, active low)
 *      PA1 -> LCD_DC/RS (data/command select)
 *      PA4 -> LCD_RST  (reset, active low)
 *
 *  To add a feature:
 *    1. Implement EXT_SPI_FeatureInit()  - one-time setup after the SPI2
 *       peripheral is up.  Called from EXT_SPI_Init().
 *    2. Implement EXT_SPI_FeaturePoll()   - periodic work from the super
 *       loop.  Called from EXT_SPI_Poll().
 *    Both hooks are weak: a future project simply defines strong versions
 *    in its own source files without editing this module or main.c.
 *
 *  Low-level helpers (EXT_SPI_Transfer, LCD pin control) are provided below.
 *  See ext_spi.c for a worked ST7789-style LCD example.
 * ============================================================================
 */

/* --- Extension hooks (override to add features) --------------------------- */
void EXT_SPI_FeatureInit(void);   /* weak - feature one-time init   */
void EXT_SPI_FeaturePoll(void);   /* weak - feature periodic poll   */

/* --- Footprint API -------------------------------------------------------- */
void EXT_SPI_Init(void);          /* call once after MX_SPI2_Init() */
void EXT_SPI_Poll(void);          /* call from the super loop       */
uint8_t EXT_SPI_IsReady(void);    /* 1 if hspi2 is initialised      */

/**
 * @brief  Full-duplex SPI transfer (blocking).
 * @param  tx   TX data (NULL -> sends 0xFF).
 * @param  rx   RX data (NULL -> discards).
 * @param  len  Number of bytes.
 * @return HAL status (HAL_OK on success).
 */
HAL_StatusTypeDef EXT_SPI_Transfer(const uint8_t *tx, uint8_t *rx, uint16_t len);

/* --- LCD control pins (PA0 CS, PA1 DC, PA4 RST) --------------------------- */
#define EXT_SPI_LCD_CS_SET()   HAL_GPIO_WritePin(LCD_CS_GPIO_Port,    LCD_CS_Pin,    GPIO_PIN_SET)
#define EXT_SPI_LCD_CS_RESET() HAL_GPIO_WritePin(LCD_CS_GPIO_Port,    LCD_CS_Pin,    GPIO_PIN_RESET)
#define EXT_SPI_LCD_DC_SET()   HAL_GPIO_WritePin(LCD_DC_RS_GPIO_Port, LCD_DC_RS_Pin, GPIO_PIN_SET)
#define EXT_SPI_LCD_DC_RESET() HAL_GPIO_WritePin(LCD_DC_RS_GPIO_Port, LCD_DC_RS_Pin, GPIO_PIN_RESET)
#define EXT_SPI_LCD_RST_SET()  HAL_GPIO_WritePin(LCD_RST_GPIO_Port,   LCD_RST_Pin,   GPIO_PIN_SET)
#define EXT_SPI_LCD_RST_RESET() HAL_GPIO_WritePin(LCD_RST_GPIO_Port,  LCD_RST_Pin,   GPIO_PIN_RESET)

#ifdef __cplusplus
}
#endif

#endif /* EXT_SPI_H */
